/*Implemente una aplicación que permita controlar los asistentes a una fiesta; para ello deberá ingresar la edad, sexo (masculino y femenino) y estado civil (soltero, casado, viudo y divorciado) del asistente (1 punto). Luego muestre la siguientes estadísticas (1 punto):
o Total de asistentes
o Total de personas mayores de edad
o Total de personas menores de edad
o Total de hombres
o Total de mujeres
o Total de solteros
o Total de casados
o Total de viudos
o Total de divorciados
o Porcentaje de hombres
o Porcentaje de mujeres
Aplique los conceptos de encapsulación y abstracción de POO e implemente la(s) clase(s) necesaria(s) con atributos privados, el uso de los métodos getters y setters, el constructor y los métodos adicionales que requiera su aplicación (3 puntos).*/
package lab3fiesta;

/**
 *
 * @author User
 */
public class LAB3FIESTA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            invitados e1 = new invitados();
            e1.ejecutar();
        }

    }
    

