/*Implemente una aplicación que permita controlar los asistentes a una fiesta; para ello:
menu principal: si ingresa 1 para añadir otra persona, ingresa 2 ver estadisticas, ingresa 3 para salir del programa.
si ingresa 1, ingresar la edad, sexo (1 para masculino y 2 para femenino) y estado civil (1 para soltero, 2 para casado, 3 para viudo y 4 para divorciado) del asistente (1 punto). vuelva al menu principal.
si ingresa 2, muestre la siguientes estadísticas:
o Total de asistentes = cantidad de edad ingresadas
o Total de personas mayores de edad = cantidad de edad ingresadas mayores a 18
o Total de personas menores de edad = cantidad de edad ingresadas menores a 18
o Total de hombres = cantidad de sexo ingresados 1
o Total de mujeres = cantidad de sexo ingresados 2
o Total de solteros = cantidad de estado civil ingresados 1
o Total de casados  = cantidad de estado civil ingresados 2
o Total de viudos = cantidad de estado civil ingresados 3
o Total de divorciados = cantidad de estado civil ingresados 4
o Porcentaje de hombres = total de hombres / total de asistentes * 100
o Porcentaje de mujeres = total de mujeres / total de asistentes * 100
Aplique los conceptos de encapsulación y abstracción de POO e implemente la(s) clase(s) necesaria(s) con atributos privados, el uso de los métodos getters y setters, el constructor y los métodos adicionales que requiera su aplicación (3 puntos).
si ingresa 3 salga del programa*/


package lab3fiesta;

import java.util.Scanner;
//import static lab3fiesta.person.menu;

public class invitados {
    private int edad;
    private int sexo;
    private int estadoCivil;
    private int totalAsistentes;
    private int totalMayoresEdad;
    private int totalMenoresEdad;
    private int totalHombres;
    private int totalMujeres;
    private int totalSolteros;
    private int totalCasados;
    private int totalViudos;
    private int totalDivorciados;
    private double porcentajeHombres;
    private double porcentajeMujeres;
    private int opcion;
    private int contador;
    private int contador2;
    private int contador3;
    private int contador4;
    private int contador5;
    private int contador6;
    private int contador7;
    private int contador8;
    private int contador9;
    private int contador10;
    private int contador11;

    public invitados() {
        this.edad = 0;
        this.sexo = 0;
        this.estadoCivil = 0;
        this.totalAsistentes = 0;
        this.totalMayoresEdad = 0;
        this.totalMenoresEdad = 0;
        this.totalHombres = 0;
        this.totalMujeres = 0;
        this.totalSolteros = 0;
        this.totalCasados = 0;
        this.totalViudos = 0;
        this.totalDivorciados = 0;
        this.porcentajeHombres = 0;
        this.porcentajeMujeres = 0;
        this.opcion = 0;
        this.contador = 0;
        this.contador2 = 0;
        this.contador3 = 0;
        this.contador4 = 0;
        this.contador5 = 0;
        this.contador6 = 0;
        this.contador7 = 0;
        this.contador8 = 0;
        this.contador9 = 0;
        this.contador10 = 0;
        this.contador11 = 0;

    }
    //getters
    public int getEdad() {
        return edad;
    }
    public int getSexo() {
        return sexo;
    }
    public int getEstadoCivil() {
        return estadoCivil;
    }
    public int getTotalAsistentes() {
        return totalAsistentes;
    }
    public int getTotalMayoresEdad() {
        return totalMayoresEdad;
    }
    public int getTotalMenoresEdad() {
        return totalMenoresEdad;
    }
    public int getTotalHombres() {
        return totalHombres;
    }
    public int getTotalMujeres() {
        return totalMujeres;
    }
    public int getTotalSolteros() {
        return totalSolteros;
    }
    public int getTotalCasados() {
        return totalCasados;
    }
    public int getTotalViudos() {
        return totalViudos;
    }
    public int getTotalDivorciados() {
        return totalDivorciados;
    }
    public double getPorcentajeHombres() {
        return porcentajeHombres;
    }
    public double getPorcentajeMujeres() {
        return porcentajeMujeres;
    }
    public int getOpcion() {
        return opcion;
    }
    public int getContador() {
        return contador;
    }
    public int getContador2() {
        return contador2;
    }
    public int getContador3() {
        return contador3;
    }
    public int getContador4() {
        return contador4;
    }
    public int getContador5() {
        return contador5;
    }
    public int getContador6() {
        return contador6;
    }
    public int getContador7() {
        return contador7;
    }
    public int getContador8() {
        return contador8;
    }
    public int getContador9() {
        return contador9;
    }
    public int getContador10() {
        return contador10;
    }
    public int getContador11() {
        return contador11;
    }
    //setters
    public void setEdad(int edad) {
        this.edad = edad;
    }
    public void setSexo(int sexo) {
        this.sexo = sexo;
    }
    public void setEstadoCivil(int estadoCivil) {
        this.estadoCivil = estadoCivil;
    }
    public void setTotalAsistentes(int totalAsistentes) {
        this.totalAsistentes = totalAsistentes;
    }
    public void setTotalMayoresEdad(int totalMayoresEdad) {
        this.totalMayoresEdad = totalMayoresEdad;
    }
    public void setTotalMenoresEdad(int totalMenoresEdad) {
        this.totalMenoresEdad = totalMenoresEdad;
    }
    public void setTotalHombres(int totalHombres) {
        this.totalHombres = totalHombres;
    }
    public void setTotalMujeres(int totalMujeres) {
        this.totalMujeres = totalMujeres;
    }
    public void setTotalSolteros(int totalSolteros) {
        this.totalSolteros = totalSolteros;
    }
    public void setTotalCasados(int totalCasados) {
        this.totalCasados = totalCasados;
    }
    public void setTotalViudos(int totalViudos) {
        this.totalViudos = totalViudos;
    }
    public void setTotalDivorciados(int totalDivorciados) {
        this.totalDivorciados = totalDivorciados;
    }
    public void setPorcentajeHombres(double porcentajeHombres) {
        this.porcentajeHombres = porcentajeHombres;
    }
    public void setPorcentajeMujeres(double porcentajeMujeres) {
        this.porcentajeMujeres = porcentajeMujeres;
    }
    public void setOpcion(int opcion) {
        this.opcion = opcion;
    }
    public void setContador(int contador) {
        this.contador = contador;
    }
    public void setContador2(int contador2) {
        this.contador2 = contador2;
    }
    public void setContador3(int contador3) {
        this.contador3 = contador3;
    }
    public void setContador4(int contador4) {
        this.contador4 = contador4;
    }
    public void setContador5(int contador5) {
        this.contador5 = contador5;
    }
    public void setContador6(int contador6) {
        this.contador6 = contador6;
    }
    public void setContador7(int contador7) {
        this.contador7 = contador7;
    }
    public void setContador8(int contador8) {
        this.contador8 = contador8;
    }
    public void setContador9(int contador9) {
        this.contador9 = contador9;
    }
    public void setContador10(int contador10) {
        this.contador10 = contador10;
    }
    public void setContador11(int contador11) {
        this.contador11 = contador11;
    }
    
    public void ingresarDatos(){
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese la edad: ");
        this.edad = entrada.nextInt();
        System.out.println("Ingrese el sexo (1 masculino , 2 femenino): ");
        this.sexo = entrada.nextInt();
        System.out.println("Ingrese el estado civil (1 soltero , 2 casado , 3 viudo , 4 divorciado): ");
        this.estadoCivil = entrada.nextInt();
    }

    public void mostrarEstadisticas(){
        System.out.println("El total de asistentes es: " + this.totalAsistentes);
        System.out.println("El total de mayores de edad es: " + this.totalMayoresEdad);
        System.out.println("El total de menores de edad es: " + this.totalMenoresEdad);
        System.out.println("El total de hombres es: " + this.totalHombres);
        System.out.println("El total de mujeres es: " + this.totalMujeres);
        System.out.println("El total de solteros es: " + this.totalSolteros);
        System.out.println("El total de casados es: " + this.totalCasados);
        System.out.println("El total de viudos es: " + this.totalViudos);
        System.out.println("El total de divorciados es: " + this.totalDivorciados);
        System.out.println("El porcentaje de hombres es: " + this.porcentajeHombres);
        System.out.println("El porcentaje de mujeres es: " + this.porcentajeMujeres);
    }

    public void mostrarMenu(){
        System.out.println("1. Ingresar datos de un invitado");
        System.out.println("2. Mostrar estadísticas");
        System.out.println("3. Salir");
    }
    

    public void invitadosa() {
        System.out.println("ALERTA - Reinicio total del programa");
        this.edad = 0;
        this.sexo = 0;
        this.estadoCivil = 0;
        this.totalAsistentes = 0;
        this.totalMayoresEdad = 0;
        this.totalMenoresEdad = 0;
        this.totalHombres = 0;
        this.totalMujeres = 0;
        this.totalSolteros = 0;
        this.totalCasados = 0;
        this.totalViudos = 0;
        this.totalDivorciados = 0;
        this.porcentajeHombres = 0;
        this.porcentajeMujeres = 0;
        this.opcion = 0;
        this.contador = 0;
        this.contador2 = 0;
        this.contador3 = 0;
        this.contador4 = 0;
        this.contador5 = 0;
        this.contador6 = 0;
        this.contador7 = 0;
        this.contador8 = 0;
        this.contador9 = 0;
        this.contador10 = 0;
        this.contador11 = 0;

    }
    public void calcularEstadisticas(){
        this.totalAsistentes = (this.contador + this.contador2);
        this.totalMayoresEdad = this.contador;
        this.totalMenoresEdad = this.contador2;
        this.totalHombres = this.contador3;
        this.totalMujeres = this.contador4;
        this.totalSolteros = this.contador5;
        this.totalCasados = this.contador6;
        this.totalViudos = this.contador7;
        this.totalDivorciados = this.contador8;
        this.porcentajeHombres = (this.totalHombres * 100) / this.totalAsistentes;
        this.porcentajeMujeres = (this.totalMujeres * 100) / this.totalAsistentes;
    }


    //@SuppressWarnings("empty-statement")
    
    public void ejecutar(){
        Scanner sc = new Scanner(System.in);
        do{
            mostrarMenu();
            this.opcion = sc.nextInt();
            switch(this.opcion){
                case 1 -> {
                    ingresarDatos();
                    if(this.edad >= 18){
                        this.contador++;
                    }else if (this.edad < 18 && this.edad > 0){
                        this.contador2++;
                    }
                    else{
                        invitadosa();
                    }
                    
                    if(this.sexo == 1){
                        this.contador3++;
                    }else if (this.sexo == 2){
                        this.contador4++;
                    }
                    else{
                        invitadosa();
                    }
                    
                    if(this.estadoCivil == 1){
                        this.contador5++;
                    }else if (this.estadoCivil == 2){
                        this.contador6++;
                    }else if (this.estadoCivil == 3){
                        this.contador7++;
                    }else if (this.estadoCivil == 4){
                        this.contador8++;
                    }
                    else{
                        invitadosa();
                    }
                }
                case 2 -> {
                    calcularEstadisticas();
                    mostrarEstadisticas();
                }
                case 3 -> System.out.println("Gracias por utilizar el programa");
                default -> System.out.println("Opcion incorrecta");
            }
        }while(this.opcion != 3);
    }
}
