//clase contenedora con un atributo de tipo vector (o lista) para guardar las intancias contenidas
//clase contenedora con un método para agregar nuevas instancias en el vector (o lista) 
//método para mostrar las estadísticas
package lab3fiesta;

/**
 *
 * @author Camila Diaz
 */
public class Contenedora {
    private invitados[] invitados;
    private int contador;
    
    public Contenedora(){
        invitados = new invitados[100];
        contador = 0;
    }
    
    public void agregarInvitado(invitados invitado){
        invitados[contador] = invitado;
        contador++;
    }

    public invitados[] getInvitados() {
        return invitados;
    }

    public void setInvitados(invitados[] invitados) {
        this.invitados = invitados;
    }

    
}
