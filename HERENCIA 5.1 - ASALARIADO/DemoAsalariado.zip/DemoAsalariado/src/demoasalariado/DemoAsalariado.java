//main
package demoasalariado;

/**
 *
 * @author Camila Díaz
 */
public class DemoAsalariado {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        System.out.println();
        System.out.println("------------------------------");
        System.out.println();
        
        Asalariado asalariado = new Asalariado("Camila", 7654987, 30, 1000000.0);
        asalariado.imprimir();
        
        System.out.println();
        System.out.println("------------------------------");
        System.out.println();
        
        EmpleadoProduccion empleadoProduccion = new EmpleadoProduccion("Laura", 87654321, 30, 1000000.0,"mañana");
        empleadoProduccion.imprimir();

        System.out.println();
        System.out.println("------------------------------");
        System.out.println();

        EmpleadoDistribucion empleadoDistribucion = new EmpleadoDistribucion("Juan", 12345678, 30, 1000000.0, "camión");
        empleadoDistribucion.imprimir();
        
        System.out.println();
        System.out.println("------------------------------");
        System.out.println();

    }
    
}
