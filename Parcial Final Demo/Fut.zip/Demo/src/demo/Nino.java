/*
 * Codifique en java la clase Nino
1. Aplique herencia de la clase Deportista
2. En el método cuotaAPagar retorne el valor de aporte TIPOA 
 */
package demo;

/**
 *
 * @author User
 */
public class Nino extends Deportista {

    public Nino(String identificacion) {
        super(identificacion);
        //TODO Auto-generated constructor stub
    }

    @Override
    public double cuotaAPagar() {
        return Enum.ValorCuota.TIPOA.getValor();
    }

}
