/*
 * Para facilitar la centralización de los valores de la cuota, el líder de desarrollo solicita crear un
enumerador llamado ValorCuota que permita, obtener el valor a pagar según la información
suministrada la escuela de futbol Talents Players, implemente en java una clase tipo enum
que disponga los objetos con los 5 tipos de cuotas

Por en la escuela de futbol Talents Players, reciben deportistas clasificados de la siguiente manera
niños, adolescentes y adultos, para el cobro de la mensualidad dispone los siguientes tipos de cuotas
 Tipo A: $ 10.000
 Tipo B: $ 20.000
 Tipo C: $ 30.000
 Tipo D: $ 40.000
 Tipo E: $ 50.000
 */
package demo;

/**
 *
 * @author User
 */
public class Enum {
    //tipos de cuotas
    public enum ValorCuota {
        TIPOA(10000), TIPOB(20000), TIPOC(30000), TIPOD(40000), TIPOE(50000);
        
        private final int valor;
        
        ValorCuota(int valor) {
            this.valor = valor;
        }
        
        public int getValor() {
            return valor;
        }
    }

}
