/*
 * Codifique en java la clase Escuela
1. Incluya un atributo nombre
2. Implemente la interface PatronEscuela
3. Aplique patrón contenedor para el método agregarDeportista
e.agregarDeportista(new Nino("123456"));
        e.agregarDeportista(new Adolescente("654321",14));
        e.agregarDeportista(new Adolescente("789654",17));
        e.agregarDeportista(new Adulto("456987",true));
        e.agregarDeportista(new Adulto("741258",false));
        e.imprimirListaDeCuotas();
4. Implemente el método imprimirListaDeCuotas
Ejemplo de la salida por consola clase demo

*****Escuela Talents Players******
El valor pagado por: 123456 es: $10000.0 tipo de deportista Nino
El valor pagado por: 654321 es: $20000.0 tipo de deportista Adolescente
El valor pagado por: 789654 es: $30000.0 tipo de deportista Adolescente
El valor pagado por: 456987 es: $40000.0 tipo de deportista Adulto
El valor pagado por: 741258 es: $50000.0 tipo de deportista Adulto

 */
package demo;

/**
 *
 * @author User
 */
public class Escuela {
    //patron contendedor para el metodo agregar deportista
    private String nombre;
    private Deportista[] deportistas;
    private int contador;

    public Escuela(String nombre) {
        this.nombre = nombre;
        this.deportistas = new Deportista[100];
        this.contador = 0;
    }

    public void agregarDeportista(Deportista deportista) {
        this.deportistas[contador] = deportista;
        this.contador++;
    }

    public void imprimirListaDeCuotas() { //imprime el public String toString(){
        //return "El valor pagado por: "+identificacion+" es: $"+cuotaAPagar()+" tipo de deportista "+this.getClass().getName();
        //}

        System.out.println("*****Escuela Talents Players******");
        for (int i = 0; i < contador; i++) {
            System.out.println(deportistas[i].toString());
        }
        
    }
}
