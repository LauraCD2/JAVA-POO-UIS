/*
 * Codifique en java la clase Adulto
1. Aplique herencia de la clase Deportista
2. Incluya un atributo booleano llamado hijos inscritos 
3. En el método cuotaAPagar retorne el valor de aporte TIPOD si el atributo hijos
inscritos es verdadero, de lo contrario retornar el valor de aporte TIPOE 

Para los métodos cuotaAPagar se debe hacer uso de la clase Enum.java
 */
package demo;

/**
 *
 * @author User
 */
public class Adulto extends Deportista {
        
        private boolean hijosInscritos;
        
        public Adulto(String identificacion, boolean hijosInscritos) {
            super(identificacion);
            this.hijosInscritos = hijosInscritos;
        }

        @Override
        public double cuotaAPagar() {
            if (hijosInscritos) {
                return Enum.ValorCuota.TIPOD.getValor();
            } else {
                return Enum.ValorCuota.TIPOE.getValor();
            }
        }
    
}
