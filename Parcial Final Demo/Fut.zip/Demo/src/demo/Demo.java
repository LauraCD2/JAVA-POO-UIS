/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package demo;

/**
 *
 * @author 
 */
public class Demo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Escuela e= new Escuela("Talents Players");
        e.agregarDeportista(new Nino("123456"));
        e.agregarDeportista(new Adolescente("654321",14));
        e.agregarDeportista(new Adolescente("789654",17));
        e.agregarDeportista(new Adulto("456987",true));
        e.agregarDeportista(new Adulto("741258",false));
        e.imprimirListaDeCuotas();
    }
    
}
