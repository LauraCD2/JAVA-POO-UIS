/*
 * Codifique en java la clase Adolescente
1. Aplique herencia de la clase Deportista
2. Incluya un atributo edad
3. En el método cuotaAPagar retorne el valor de aporte TIPOB si la edad es menor a 15
años y el valor de aporte TIPOC si la edad es 15 años o más 

//TIPOB y TIPOC está en la clase Enum.java
 */
package demo;

/**
 *
 * @author User
 */
public class Adolescente extends Deportista {
        
        private int edad;
        
        public Adolescente(String identificacion, int edad) {
            super(identificacion);
            this.edad = edad;
        }

        @Override
        public double cuotaAPagar() {
            if (edad < 15) {
                return Enum.ValorCuota.TIPOB.getValor();
            } else {
                return Enum.ValorCuota.TIPOC.getValor();
            }
        }

}
