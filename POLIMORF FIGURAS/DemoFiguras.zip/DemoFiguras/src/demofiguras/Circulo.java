
package demofiguras;

/**
 *
 * @author Camila Díaz
 */
public class Circulo extends Figura {
    private int radio;

    public Circulo(int radio) {
        this.radio = radio;
    }

    public int area (){
        return (int) (Math.PI * radio * radio);
    }

    public int perimetro (){
        return (int) (2 * Math.PI * radio);
    }
    
}