
package demofiguras;

/**
 *
 * @author Camila Díaz
 */
public abstract class Figura {
    public abstract int area();
    public abstract int perimetro();
    public String toString(){
        return "Area: " + area() + " Perimetro: " + perimetro();
    }
	
}
