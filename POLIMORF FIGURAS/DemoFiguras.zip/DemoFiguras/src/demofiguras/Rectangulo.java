
package demofiguras;

/**
 *
 * @author Camila Díaz
 */
public class Rectangulo extends Figura {
    private int ancho, alto;

    public Rectangulo(int ancho, int alto) {
        this.ancho = ancho;
        this.alto = alto;
    }

    public int area (){
        return ancho * alto;
    }

    public int perimetro (){
        return 2 * (ancho + alto);
    }
	
}
