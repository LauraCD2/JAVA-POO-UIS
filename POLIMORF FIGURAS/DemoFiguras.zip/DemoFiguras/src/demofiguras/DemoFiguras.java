
package demofiguras;

/**
 *
 * @author Camila Díaz
 */
public class DemoFiguras {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		Figura[] figs = new Figura[3];
		figs[0] = new Rectangulo(5, 10);
		figs[1] = new Circulo(10);
		figs[2] = new Rectangulo(10, 20);
		for (Figura fig : figs){
			System.out.println(fig);
		}
	}
	
	public void test2 (){
		Figura[] figs = new Figura[3];
		figs[0] = new Rectangulo(5, 10);
		figs[1] = new Circulo(10);
		figs[2] = new Figura();
		for (int i = 0; i < figs.length; i++){
			Figura fig = figs[i];
			System.out.println(fig);
		}
	}
}
