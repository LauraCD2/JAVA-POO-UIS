package herencia.pkg01.pkg12;

/**
 *
 * @author Camila Díaz
 */
public class Cirujano extends Medico {
    // Método sobrescito
    public void tratarPaciente() {
    System.out.println("Realizar una cirugía");
    }
    // Método adicional
    public void realizarIncision() {
    System.out.println("usando el escalpelo");
    }
}