package herencia.pkg01.pkg12;

/**
 *
 * @author Camila Díaz
 */
public class Generalista extends Medico {
    public void darConsejo() {
    System.out.println("Aconseja como tratar la enfermedad");
    }
}
