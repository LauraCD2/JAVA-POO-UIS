package herencia.pkg01.pkg12;

/**
 *
 * @author Camila Díaz
 */
public class Medico {
	private String nombre;
    public void tratarPaciente(){
        System.out.println("Realiza una revisión");
    }
}
