package herencia.pkg01.pkg12;

/**
 *
 * @author Camila Díaz
 */
public class DemoHospital {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        // Crear un objeto de la clase Medico
        Generalista g = new Generalista();
        Cirujano c = new Cirujano();

        // Invocar métodoszs
        g.tratarPaciente();
        g.darConsejo();
        g.tratarPaciente();

        c.tratarPaciente();
        c.realizarIncision();

    }
    
}
