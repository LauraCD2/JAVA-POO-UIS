package Demo2;

import relacionesclases.Direccion;

/**
 *
 * @author Camila Diaz
 */
public class Estudiante {
    private String nombre;
    private int nivel;
    private Direccion dir;

    //getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public Direccion getDir() {
        return dir;
    }

    public void setDir(Direccion dir) {
        this.dir = dir;
    }

    //constructor

    public Estudiante(String nombreIni, int nivelIni){
        nombre=nombreIni;
        nivel=nivelIni;
    }

    public Estudiante (String nombreIni, int nivelIni, Direccion dirIni){
        nombre=nombreIni;
        nivel=nivelIni;
        dir=dirIni;
    }

    public void imprimir (){
        System.out.println("Nombre: "+nombre);
        System.out.println("Nivel: "+nivel);
        System.out.println("Dirección: ");
        System.out.println("-" + dir.getTexto());
        System.out.println("-" + dir.getBarrio() + ", " + dir.getCiudad());
        System.out.println("");
    }
}
