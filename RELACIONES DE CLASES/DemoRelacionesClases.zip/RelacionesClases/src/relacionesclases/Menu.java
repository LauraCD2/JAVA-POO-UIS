/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package relacionesclases;
import java.util.Scanner;
import Demo2.Estudiante;
/**
 *
 * @author Estudiantes
 */
public class Menu {
    int opcion;
    Scanner sc = new Scanner(System.in);
 public void mostrarMenu(){
     System.out.println("1. Agregar info estudiante");
     System.out.println("2. Imprimir estudiantes de que escuela");
     System.out.println("3. Salir");
     System.out.println("Elija una opcion");

        opcion = sc.nextInt();
    switch(opcion){
    case 1:
    
    break;
    case 2:
    
    break;
    case 3:
    System.out.println("Gracias por usar el programa");
    break;
    default:
    System.out.println("Opcion no valida");
    }
 }



}
