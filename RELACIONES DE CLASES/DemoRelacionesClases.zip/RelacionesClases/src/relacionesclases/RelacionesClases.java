//crear objetos de la clase Direccion
package relacionesclases;

import Demo2.Estudiante;
import java.util.Scanner;

/**
 *
 * @author Camila Diaz
 */
public class RelacionesClases {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Direccion d1 = new Direccion("Calle 2", "Suba", "Bogotá");
        Direccion d2 = new Direccion("Carrera 8", "La Ronda", "Floridablanca");
        Direccion d3 = new Direccion("Calle 3", "Usaquén", "Bogotá");
        Direccion d4 = new Direccion("Calle 3", "Chapinero", "Bogotá");
        Estudiante e1 = new Estudiante("Camila", 2); // manda error porque falta atributo Dirección
        Estudiante e2 = new Estudiante("Juan", 6, d2);
        Estudiante e3 = new Estudiante("María", 7, d3);
        Estudiante e4 = new Estudiante("Pedro", 6, d2); //misma direccion que e2
        
        //como cambiar un atributo de un objeto, ejm: cambiar la direccion de e4
        e4.setDir(d4); //cambiar direccion de e4 a d4

        //imprimir los datos de los estudiantes
        //e1.imprimir();
        //e2.imprimir(); //d2
        //e3.imprimir();
        //e4.imprimir();

        //crear objetos de la clase Escuela
        Escuela esc1 = new Escuela("Escuela de Ingeniería de Sistemas");
        Escuela esc2 = new Escuela("Escuela de Ingeniería Eléctrica, Electrónica y Telecomunicaciones - E3T");

        //agregar estudiantes a la escuela
        esc2.agregarEstudiante(e2); //E3T JUAN
        esc1.agregarEstudiante(e1); //S C
        esc1.agregarEstudiante(e3); //S M
        esc1.agregarEstudiante(e4); //S P


        //imprimir los estudiantes de la escuela
        esc1.imprimirNivel(6);
        esc1.imprimirNivel(6);

        //crear objetos de la clase Facultad
        Facultad f1 = new Facultad("Facultad de Ingenierías Fisicomecánicas");
        Facultad f2 = new Facultad("Facultad de Ingenierías E3T");

        //agregar escuelas a la facultad
        //f1.agregarEscuela(esc1);

        //imprimir estudiantes del nivel 6 de la facultad fisicomecánicas de la escuela ingeniería de sistemas
        //f1.imprimirNivel(6);
        
       //crear menu para que escoja por consola de que escuela y que nivel quiere ver los estudiantes

       Menu menu = new Menu();
         //menu.mostrarMenu();

/*
         //crear estudiantes
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el nombre del estudiante: ");
        String nombre = sc.nextLine();
        System.out.println("Ingrese el nivel del estudiante: ");
        int nivel = sc.nextInt();
        sc.nextLine();
        System.out.println("Ingrese la dirección del estudiante: ");
        String texto = sc.nextLine();
        System.out.println("Ingrese el barrio del estudiante: ");
        String barrio = sc.nextLine();
        System.out.println("Ingrese la ciudad del estudiante: ");
        String ciudad = sc.nextLine();
        Direccion dir = new Direccion(texto, barrio, ciudad);
        Estudiante est = new Estudiante(nombre, nivel, dir);
    }

*/
    
}
}
