//crear objetos de la clase Direccion
package relacionesclases;

import Demo2.Estudiante;

/**
 *
 * @author Estudiantes
 */
public class RelacionesClases {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Direccion d1 = new Direccion("Calle 2", "Suba", "Bogotá");
        Direccion d2 = new Direccion("Carrera 8", "La Ronda", "Floridablanca");
        Direccion d3 = new Direccion("Calle 3", "Usaquén", "Bogotá");
        Direccion d4 = new Direccion("Calle 3", "Chapinero", "Bogotá");
        Estudiante e1 = new Estudiante("Camila", 2); // manda error porque falta atributo Dirección
        Estudiante e2 = new Estudiante("Juan", 6, d2);
        Estudiante e3 = new Estudiante("María", 8, d3);
        Estudiante e4 = new Estudiante("Pedro", 9, d2); //misma direccion que e2
        
        //como cambiar un atributo de un objeto, ejm: cambiar la direccion de e4
        e4.setDir(d4); //cambiar direccion de e4 a d4

        //imprimir los datos de los estudiantes
        //e1.imprimir();
        //e2.imprimir(); //d2
        //e3.imprimir();
        //e4.imprimir();

        //crear objetos de la clase Escuela
        Escuela esc1 = new Escuela("Escuela Físicomecánicas");

        //agregar estudiantes a la escuela
        esc1.agregarEstudiante(e1);
        esc1.agregarEstudiante(e2);
        esc1.agregarEstudiante(e3);
        esc1.agregarEstudiante(e4);


        //imprimir los estudiantes de la escuela
        esc1.imprimirNivel(6);
        



    }
    
}
