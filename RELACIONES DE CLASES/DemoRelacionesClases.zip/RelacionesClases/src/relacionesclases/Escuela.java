//atributo nombre de la escuela y un atributo estudinate de tipo estudiante
//crear un constructor que reciba el nombre en parametro
//metodo agregarEstudiante que reciba una instancia de estudiante en parametro
//metodo imprimirNivel que imprima todos los estudiantes de un nivel dado, el nivel se pasa como parametro de metodo
package relacionesclases;

import Demo2.Estudiante;

/**
 *
 * @author Camila Diaz
 */
public class Escuela {
    public String nombre;
    public Estudiante[] estudiantes;
    public int numEstudiantes;
    public Escuela(String nombreIni) {
    nombre = nombreIni;
    estudiantes = new Estudiante[200];
    numEstudiantes = 0;
    }
    public void agregarEstudiante(Estudiante est) {
    estudiantes[numEstudiantes] = est;
    numEstudiantes++;
    }
    public void imprimirNivel(int nivel) {
    for (int i = 0; i < numEstudiantes; i++) {
    Estudiante est = estudiantes[i];
    if (est.getNivel()==nivel) {
    est.imprimir();
    }
    }
    }
    public String getNombre() { return nombre; }
    public void setNombre(String nombreSet) { nombre = nombreSet; }
    }


