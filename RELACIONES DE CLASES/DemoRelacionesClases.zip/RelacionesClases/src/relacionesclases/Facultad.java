
package relacionesclases;

/**
 *
 * @author Camila Diaz
 */
public class Facultad {
    
}
