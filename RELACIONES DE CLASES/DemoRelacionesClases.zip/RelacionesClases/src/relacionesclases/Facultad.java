
package relacionesclases;

/**
 *
 * @author Camila Diaz
 */
public class Facultad {
    
    public String nombre;
    public Escuela[] escuelas;
    public int numEscuelas;
    
    //constructor
    public Facultad(String nombreIni) {
        nombre = nombreIni;
        escuelas = new Escuela[200];
        numEscuelas = 0;
    }
    
    //metodo agregarEscuela que reciba una instancia de escuela en parametro
    public void agregarEscuela(Escuela esc) {
        escuelas[numEscuelas] = esc;
        numEscuelas++;
    }
    
    //metodo imprimirNivel que imprima todos los estudiantes de un nivel dado, el nivel se pasa como parametro de metodo
    public void imprimirNivel(int nivel) {
        for (int i = 0; i < numEscuelas; i++) {
            Escuela esc = escuelas[i];
            esc.imprimirNivel(nivel);
        }
    }
    
    //getters y setters 
    public String getNombre() { return nombre; }
    public void setNombre(String nombreSet) { nombre = nombreSet; }
    
}
