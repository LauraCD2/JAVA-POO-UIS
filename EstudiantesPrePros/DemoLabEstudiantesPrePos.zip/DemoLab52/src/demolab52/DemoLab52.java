package demolab52;

/**
 *
 * @author Camila Díaz
 */

public class DemoLab52 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        EstudiantePregrado estudiantePregrado = new EstudiantePregrado();
        estudiantePregrado.setNombre("Laura");
        estudiantePregrado.setNotas(new double[]{30, 70, 90});
        estudiantePregrado.calcularNota();
        System.out.println("Estudiante Pregrado:");
        System.out.println("Nombre: " + estudiantePregrado.getNombre());
        System.out.println("Nota Final: " + estudiantePregrado.getNotaFinal());
        System.out.println("Es Apto: " + estudiantePregrado.isEsApto());

        System.out.println();
        System.out.println("------------------------------");
        System.out.println();

        EstudiantePosgrado estudiantePosgrado = new EstudiantePosgrado();
        estudiantePosgrado.setNombre("Camila");
        estudiantePosgrado.setNotas(new double[]{80, 90, 100});
        estudiantePosgrado.calcularNota();
        System.out.println("Estudiante Posgrado:");
        System.out.println("Nombre: " + estudiantePosgrado.getNombre());
        System.out.println("Nota Final: " + estudiantePosgrado.getNotaFinal());
        System.out.println("Es Apto: " + estudiantePosgrado.isEsApto());



    }
    
}
