/*
 * Aplicando el concepto de herencia implementar las clases Estudiante Pregrado y Estudiante Posgrado con el método especializado que indique si es apto o no. 
 * Apto si (examen 1 + examen 2 + examen 3)/3>=70
 * Imprima en consola los resultados de los diferentes estudiantes que establezca con datos supuestos.
 */
package demolab52;

/**
 *
 * @author Estudiantes
 */
public class EstudiantePregrado extends Estudiante{

    public EstudiantePregrado() {
        super();
    }

    public EstudiantePregrado(String nombre, double[] notas) {
        super(nombre, notas);
    }
    
    @Override
    public void calcularNota() {
        notaFinal = 0;
        for (int i = 0; i < notas.length; i++) {
            notaFinal += notas[i];
        }
        notaFinal/=notas.length;
        if (notaFinal >= 70) {
            esApto = true;
        } else {
            esApto = false;
        }
    }
    
    public boolean isEsApto() {
        return esApto;
    }

    public void setEsApto(boolean esApto) {
        this.esApto = esApto;
    }

}
