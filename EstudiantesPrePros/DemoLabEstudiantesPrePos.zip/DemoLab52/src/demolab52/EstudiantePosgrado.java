/*
 * Aplicando el concepto de herencia implementar las clases Estudiante Pregrado y Estudiante Posgrado con el método especializado que indique si es apto o no. 
 * Apto si (examen 1 + examen 2 + examen 3)/3>=80
 * Imprima en consola los resultados de los diferentes estudiantes que establezca con datos supuestos.
 */
package demolab52;

/**
 *
 * @author Camila Diaz
 */
public class EstudiantePosgrado extends Estudiante{

    public EstudiantePosgrado() {
        super();
    }

    public EstudiantePosgrado(String nombre, double[] notas) {
        super(nombre, notas);
    }
    
    @Override
    public void calcularNota() {
        notaFinal = 0;
        for (int i = 0; i < notas.length; i++) {
            notaFinal += notas[i];
        }
        notaFinal/=notas.length;
        if (notaFinal >= 80) {
            esApto = true;
        } else {
            esApto = false;
        }
    }
    
    public boolean isEsApto() {
        return esApto;
    }

    public void setEsApto(boolean esApto) {
        this.esApto = esApto;
    }
}
