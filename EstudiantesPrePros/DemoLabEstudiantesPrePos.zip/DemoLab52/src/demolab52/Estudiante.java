//Para cada estudiante se registra su nombre, 3 notas de exámenes y la nota final del curso.


package demolab52;
import java.util.Scanner;

/**
 *
 * @author Camila Díaz
 */

public class Estudiante {
    protected double notas[];
    protected String nombre;
    protected double notaFinal;
    protected boolean esApto;
    
    public Estudiante() {
        notas = new double[3];
    }
    
    /**
     *
     * @param nombre
     * @param notas
     */
    public Estudiante(String nombre, double notas[]) {
        this.notas = notas;
        calcularNota();
    }
    
    public void calcularNota() {
        notaFinal = 0;
        for (int i = 0; i < notas.length; i++) {
            notaFinal += notas[i];
        }
        notaFinal/=notas.length;
    }

    public double[] getNotas() {
        return notas;
    }

    public void setNotas(double[] notas) {
        this.notas = notas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getNotaFinal() {
        return notaFinal;
    }

    public void setNotaFinal(double notaFinal) {
        this.notaFinal = notaFinal;
    }

    public boolean isEsApto() {
        return esApto;
    }

    public void setEsApto(boolean esApto) {
        this.esApto = esApto;
    }

/* 
    public void imprimir() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Notas: ");
        for (int i = 0; i < notas.length; i++) {
            System.out.println("Nota " + (i+1) + ": " + notas[i]);
        }
        System.out.println("Nota final: " + notaFinal);
        System.out.println("Es apto: " + esApto);
    }

    public void leer() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el nombre del estudiante: ");
        nombre = sc.nextLine();
        for (int i = 0; i < notas.length; i++) {
            System.out.println("Ingrese la nota " + (i+1) + ": ");
            notas[i] = sc.nextDouble();
        }
        calcularNota();
        esApto = notaFinal >= 80;
    }

*/


}
