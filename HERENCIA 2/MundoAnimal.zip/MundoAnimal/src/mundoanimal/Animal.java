package mundoanimal;

/**
 *
 * @author Camila Díaz
 */
public class Animal {

    public void comer() {
    System.out.println("Yumi Yumi");
    }
    
    public void dormir() {
    System.out.println("Zzzzzzzzzz");
    }
    
    public void desplazarse() {
    System.out.println("Caminando por las calles ....");
    }
    
    public void hacerRuido() {
    System.out.println("Haciendo ruido ...");
    }
    
}
