package mundoanimal;

/**
 *
 * @author Camila Díaz
 */
public class Perro extends Animal {
    public void hacerRuido() {
    System.out.println("Guau Guau");
    }
}
