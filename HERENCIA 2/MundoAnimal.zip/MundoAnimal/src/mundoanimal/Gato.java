package mundoanimal;

/**
 *
 * @author Camila Díaz
 */
public class Gato extends Animal {
    public void hacerRuido() {
    System.out.println("Miau Miau");
    }
    }
