
package javaapplication4;

import java.util.Scanner;

/**
 *
 * @author Estudiantes
 */
public class casacambios {

private double dolar;
    private double euro;
    private double mexicano;
    private double colombianos;
    private double total;
    private int opcion;
    public double getDolar() {
        return dolar;
    }
    public void setDolar(double dolar) {
        this.dolar = dolar;
    }
    public double getEuro() {
        return euro;
    }
    public void setEuro(double euro) {
        this.euro = euro;
    }
    public double getMexicano() {
        return mexicano;
    }
    public void setMexicano(double mexicano) {
        this.mexicano = mexicano;
    }
    public double getTotal() {
        return total;
    }
    public void setTotal(double total) {
        this.total = total;
    }
    
    public double getOpcion() {
        return opcion;
    }
    public void setOpcion(int opcion) {
        this.opcion = opcion;
    }
    
    public static void Opciones() {
        casacambios o = new casacambios();
        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Ingrese la moneda que desea cambiar: ");
            System.out.println("1. euro");
            System.out.println("2. dolar");
            System.out.println("3. mexicanos");
            System.out.println("4. euro y dolar");
            System.out.println("5. euro y mexicanos");
            System.out.println("6. dolar y mexicanos");
            System.out.println("7. euro, dolar y mexicanos");

            int opcion = sc.nextInt();
            switch (opcion) {
            case 1 -> {
                System.out.println("Ingrese el monto en euros: ");
                o.setEuro(sc.nextDouble());
                o.setTotal((o.getEuro()/1.02)*4998.76);
                System.out.println("El total en pesos colombianos es: "+o.getTotal());
                }
            case 2 -> {
                System.out.println("Ingrese el monto en dolares: ");
                o.setDolar(sc.nextDouble());
                o.setTotal((o.getDolar()*4998.76));
                System.out.println("El total en pesos colombianos es: "+o.getTotal());
                }
            case 3 -> {
                System.out.println("Ingrese el monto en pesos mexicanos: ");
                o.setMexicano(sc.nextDouble());
                o.setTotal((o.getMexicano()/20.49)*4998.76);
                System.out.println("El total en pesos colombianos es: "+o.getTotal());
                }
            case 4 -> {
                System.out.println("Ingrese el monto en euros: ");
                o.setEuro(sc.nextDouble());
                System.out.println("Ingrese el monto en dolares: ");
                o.setDolar(sc.nextDouble());
                o.setTotal(((o.getDolar())+(o.getEuro()/1.02))*4998.76);
                System.out.println("El total en pesos colombianos es: "+o.getTotal());
                }
            case 5 -> {
                System.out.println("Ingrese el monto en euros: ");
                o.setEuro(sc.nextDouble());
                System.out.println("Ingrese el monto en pesos mexicanos: ");
                o.setMexicano(sc.nextDouble());
                o.setTotal(((o.getMexicano()/20.49)+(o.getEuro()/1.02))*4998.76);
                System.out.println("El total en pesos colombianos es: "+o.getTotal());
                }
            case 6 -> {
                System.out.println("Ingrese el monto en dolares: ");
                o.setDolar(sc.nextDouble());
                System.out.println("Ingrese el monto en pesos mexicanos: ");
                o.setMexicano(sc.nextDouble());
                o.setTotal(((o.getMexicano()*20.49)+(o.getDolar()))*4998.76);
                System.out.println("El total en pesos colombianos es: "+o.getTotal());
                }
            case 7 -> {
                System.out.println("Ingrese el monto en euros: ");
                o.setEuro(sc.nextDouble());
                System.out.println("Ingrese el monto en dolares: ");
                o.setDolar(sc.nextDouble());
                System.out.println("Ingrese el monto en pesos mexicanos: ");
                o.setMexicano(sc.nextDouble());
                o.setTotal(((o.getMexicano()/20.49)+(o.getDolar())+(o.getEuro()/1.02))*4998.76);
                System.out.println("El total en pesos colombianos es: "+o.getTotal());
                }
            default -> System.out.println("Opcion no valida");
            }
        }
    }
    public static casacambios opciones() {
        return null;
    }
    
}
