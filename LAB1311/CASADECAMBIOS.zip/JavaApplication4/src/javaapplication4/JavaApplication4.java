package javaapplication4;

import java.util.Scanner;

/**
 *
 * @author Estudiantes
 */
public class JavaApplication4 {
public static void main(String[] args) 
    {
    /**
     * @param args the command line arguments
     */
    /**
    casacambios objcasa = new casacambios ();
    
    Scanner sc = new Scanner(System.in);
    System.out.println("digite peso mex");
    double mex = sc.nextDouble();
    int opc = sc.nextInt();
    
    objcasa.setMexicano(mex);
    objcasa.setOpcion(opc);    
    System.out.println(objcasa.getMexicano());
    System.out.println(objcasa.getOpcion());
    
     */
    casacambios.Opciones();
     
    
}
}