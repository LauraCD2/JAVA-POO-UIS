/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1001;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author LENOVO
 */
public class test5 {
    private void test5(){
        List miLista=new ArrayList();
        miLista.add(new Double(3.5));
        miLista.add(new Double(4.5));
        Iterator it= miLista.iterator();
        while(it.hasNext()){
            Double ele=(Double)it.next();
            System.out.println(ele);
        }
        
    }
}
