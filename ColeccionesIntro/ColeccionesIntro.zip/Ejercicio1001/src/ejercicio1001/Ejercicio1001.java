/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio1001;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author LENOVO
 */
public class Ejercicio1001 {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       List miLista = new ArrayList();
        miLista.add(new Double(3.5));
        miLista.add(new Double(4.5));
        for(int i=0;i<miLista.size();i++){
            Double ele=(Double) miLista.get(i);
            System.out.println(ele);
        }
        for(Object objeto: miLista){
            Double ele=(Double)objeto;
            System.out.println(ele);
        }
        NewClass a= new NewClass();
        
    }

    
}
