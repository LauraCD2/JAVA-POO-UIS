/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1001;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author LENOVO
 */
public class NewClass {
    private void test4(){
        
    
    List<Double> miLista=new ArrayList<Double>();
    miLista.add(new Double(3.5));
    miLista.add(new Double(4.5));
    for(int i=0;i<miLista.size();i++){
        Double ele=miLista.get(i);
        System.out.println(ele);
    }
    for(Double ele:miLista){
        System.out.println(ele);
    }
}
}