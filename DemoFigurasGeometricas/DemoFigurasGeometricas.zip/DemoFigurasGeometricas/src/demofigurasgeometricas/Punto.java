package demofigurasgeometricas;

/**
 *
 * @author Camila Diaz
 */

public class Punto {
    public int x;
    public int y;

    //constructor Punto
    public Punto(int xi, int yi){
        x = xi;
        y = yi;
    }
}
