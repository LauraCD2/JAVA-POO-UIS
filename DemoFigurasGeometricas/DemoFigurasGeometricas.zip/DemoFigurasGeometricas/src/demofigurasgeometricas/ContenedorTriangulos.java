package demofigurasgeometricas;

/**
 *
 * @author Camila Diaz
 */
public class ContenedorTriangulos {
    // vector contenedor de objetos de tipo Triangulo
    public Triangulo[] lista;
    public int cantidad;

    // constructor 
    public ContenedorTriangulos() {
        lista = new Triangulo[50];
        cantidad = 0;
    }

    // metodo para agregar un triangulo al vector
    public void agregarTriangulo(Triangulo t) {
        lista[cantidad] = t;
        cantidad++;
    }

    // metodo para imprimir los triangulos del vector
    public void imprimirTriangulos() {
        for (int i = 0; i < cantidad; i++) {
            lista[i].imprimir(); //método en clase Triangulo
        }
    }


}
