package demofigurasgeometricas;

/**
 *
 * @author Camila Diaz
 */

public class DemoFigurasGeometricas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Punto p1 = new Punto(12,34);
        Triangulo t1 = new Triangulo(10, 20, p1);

        Punto p2 = new Punto(12,34);
        Triangulo t2 = new Triangulo(15, 12, 13, 36);

        Triangulo t3 = new Triangulo(25, 25, p1);
        
        ContenedorTriangulos c1 = new ContenedorTriangulos();
        c1.agregarTriangulo(t1);
        c1.agregarTriangulo(t2);
        c1.agregarTriangulo(t3);

        c1.imprimirTriangulos();
    }
    
}
