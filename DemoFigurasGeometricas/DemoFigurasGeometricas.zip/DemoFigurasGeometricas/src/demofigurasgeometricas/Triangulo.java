//clase contenida
//area y perimetro de un triangulo
package demofigurasgeometricas;

/**
 *
 * @author Camila Diaz
 */

public class Triangulo {
    public int base;
    public int altura;
    public Punto loc;
    
    //constructor Triangulo
    public Triangulo(int base, int altura, Punto p){
        this.base = base;
        this.altura = altura;
    }

    //constructor Triangulo con x y y para crear el Punto
    public Triangulo(int base, int altura, int xi, int yi){
        this.base = base;
        this.altura = altura;
        loc = new Punto(xi, yi);
    }

    
    //metodo area
    public int area(){
        return (base*altura)/2;
    }
    
    //metodo perimetro
    public int perimetro(){
        return (base*3);
    }

    //metodo imprimir base y altura del triangulo
    public void imprimir(){
        System.out.println("Base: " + base +"   -   " +" Altura: " + altura);
    }

}

