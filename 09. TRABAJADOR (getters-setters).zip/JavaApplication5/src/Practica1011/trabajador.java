/*
 * Cree una aplicación de escritorio en JAVA que permita calcular el salario de un empleado. 
Al respecto se sabe que el empleado cobra un precio fijo por hora y se le descuenta el 8 % por concepto de salud y pensión. 
La aplicación debe pedir el nombre del empleado, las horas trabajadas y el sueldo que cobra por hora. 
Se pide información sobre el sueldo bruto, descuento por salud y pensión y el salario neto, con base en las siguientes consideraciones: 
• Aplique el proceso de encapsulación y abstracción para la implementación del programa. 
• Los atributos de su(s) clase(s) deben ser con nivel de acceso privado y aplique los métodos get y set. 
• Implemente el constructor y los atributos y métodos necesarios.
 */
package Practica1011;

/**
 *
 * @author Camila Diaz
 */
import java.util.Scanner;
public class trabajador {
    private String nombre;
    private int horas;
    private double sueldo;
    private double bruto;
    private double descuento;
    private double neto;

    //getters y setters
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public int getHoras() {
        return horas;
    }
    public void setHoras(int horas) {
        this.horas = horas;
    }
    public double getSueldo() {
        return sueldo;
    }
    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }
    public double getBruto() {
        return bruto;
    }
    public void setBruto(double bruto) {
        this.bruto = bruto;
    }
    public double getDescuento() {
        return descuento;
    }
    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }
    public double getNeto() {
        return neto;
    }
    public void setNeto(double neto) {
        this.neto = neto;
    }

    //constructor
    /*public trabajador(String nombre, int horas, double sueldo, double bruto, double descuento, double neto) {
        this.nombre = nombre;
        this.horas = horas;
        this.sueldo = sueldo;
        this.bruto = bruto;
        this.descuento = descuento;
        this.neto = neto;
    }*/

    public trabajador(){
        this.nombre = "";
        this.horas=0;
        this.sueldo=0;
        try (Scanner in = new Scanner(System.in)) {
            System.out.println("Ingrese el nombre del trabajador");
            this.nombre = in.nextLine();
            System.out.println("Ingrese las horas trabajadas");
            this.horas = in.nextInt();
            System.out.println("Ingrese el sueldo por hora");
            this.sueldo = in.nextDouble();
        }
        
    }
    
    //metodos
    public void calcular(){
        this.bruto = horas * sueldo;
        this.descuento = bruto * 0.08;
        this.neto = bruto - descuento;
    }
    
    public void mostrar(){
        System.out.println("El sueldo bruto es: " + getBruto());
        System.out.println("El descuento es: " + getDescuento());
        System.out.println("El sueldo neto es: " + getNeto());
    }
}
