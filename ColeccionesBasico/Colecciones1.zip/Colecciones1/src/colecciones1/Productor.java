/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package colecciones1;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author LENOVO
 */
public class Productor {
    public List getListaCadenas(){
      //  List lista= new ArrayList();
        List lista=new LinkedList();
        lista.add("Elemento Uno");
        lista.add("Elemento Dos");
        lista.add("Elemento Tres");
        
        return lista;
    }
}
