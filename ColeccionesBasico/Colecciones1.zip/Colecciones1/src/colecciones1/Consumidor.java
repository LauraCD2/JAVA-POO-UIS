/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package colecciones1;

import java.util.List;

/**
 *
 * @author LENOVO
 */
public class Consumidor {
     public void imprimir(){
        Productor pro = new Productor ();
        List tempLista=pro.getListaCadenas();
        System.out.println("El tamaño es: "+tempLista.size());
        for(int i=0;i<tempLista.size();i++){
            String st=(String)tempLista.get(i);
            System.out.println(st);
        }
    }
}
