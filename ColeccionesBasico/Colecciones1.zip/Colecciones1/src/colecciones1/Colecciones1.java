/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package colecciones1;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;


/**
 *
 * @author LENOVO
 */
public class Colecciones1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Consumidor con=new Consumidor();
        con.imprimir();
        
    }
    public void test2(){
        List<String> lista1=new ArrayList<String>();
        lista1.add("AA");
        lista1.add("BB");
        lista1.remove(0);
        lista1.size();
        
        List<String> lista2= new LinkedList<String>();
        lista2.add("CC");
        lista2.add("DD");
        lista2.remove(1);
        lista2.addAll(lista1);
        lista2.size();
    }
   
}
