package clave.pkgprotected;

/**
 *
 * @author Estudiantes
 */
public class ClaveProtected {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		Beta b = new Beta();
		b.imprimirBeta();
	}
	
}
