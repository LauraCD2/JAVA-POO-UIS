package clave.pkgprotected;

/**
 *
 * @author Camila Díaz
 */
public class Beta extends Alfa {
    
    private void imprimir() {
    System.out.println(j+k);
    }
    

    /* 
    //constructor
    public Beta() {
    setI(1); //Setter para acceder a i (private) desde la clase Alfa
    j = 2;
    k = 3;
    }
    */

    
    //constructor con super
    public Beta() {
        super(1,2,3);
    }
    
    public void imprimirBeta() {
        imprimir();
    }
}
