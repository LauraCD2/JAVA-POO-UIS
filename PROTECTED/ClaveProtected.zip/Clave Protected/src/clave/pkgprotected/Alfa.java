package clave.pkgprotected;

/**
 *
 * @author Camila Díaz
 */
public class Alfa {

    private int i;
    protected int j;
    public int k;
    
    // getter y setter
    public int getI() {
        return i;
    }
    public void setI(int i) {
        this.i = i;
    }

    //constructor
    public Alfa(int i, int j, int k) {
        this.i= i;
        this.j=j;
        this.k=k;
    }
}
