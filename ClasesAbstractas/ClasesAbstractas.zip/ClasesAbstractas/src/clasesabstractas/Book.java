/*
 *  clase Book.java que extiende de la clase Product.  La clase Book debe tener la implementación del método computeSalePrice() y devolver el 50% del valor regularPrice. Además, la clase tiene dos atributos uno String denominado publisher y otro int denominado yearPublished ambos privados; crear el constructor de la clase con parámetros que permita inicializar el estado de los atributos y encadenarlo con el constructor del padre. Además, crear los métodos get y set de los atributos de la clase.
 */
package clasesabstractas;

/**
 *
 * @author Laura Camila Díaz, Daniel Alejandro Ayala, Alejandro Velandia
 */
public class Book extends Product {
    private String publisher;
    private int yearPublished;
    
    public Book(double regularPrice, String publisher, int yearPublished){
        super(regularPrice);
        this.publisher = publisher;
        this.yearPublished = yearPublished;
    }
    
    public String getPublisher(){
        return publisher;
    }
    
    public void setPublisher(String publisher){
        this.publisher = publisher;
    }
    
    public int getYearPublished(){
        return yearPublished;
    }
    
    public void setYearPublished(int yearPublished){
        this.yearPublished = yearPublished;
    }
    
    @Override
    public double computeSalePrice(){
        return getRegularPrice() * 0.5;
    }
    
}
