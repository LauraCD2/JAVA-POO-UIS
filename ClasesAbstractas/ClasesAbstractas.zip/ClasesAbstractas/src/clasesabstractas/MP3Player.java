/*
 * La clase MP3Player se extiende de la clase abstracta Electronics.  La clase MP3Player tiene un atributo privado String denominado color. Crear el constructor de la clase con parámetros que permita inicializar el estado de los atributos (tener en cuenta de encadenar el constructor del padre con super()) y los métodos get y set de color. Además, de la implementación del método computeSalePrice(), el cual debe retornar el 90% del valor de regularPrice.
 */
package clasesabstractas;

/**
 *
 * @author Laura Camila Díaz, Daniel Alejandro Ayala, Alejandro Velandia
 */
public class MP3Player extends Electronics {
    private String color;
    
    public MP3Player(double regularPrice, String manufacturer, String color){
        super(regularPrice, manufacturer);
        this.color = color;
    }
    
    public String getColor(){
        return color;
    }
    
    public void setColor(String color){
        this.color = color;
    }
    
    @Override
    public double computeSalePrice(){
        return getRegularPrice() * 0.9;
    }
}
