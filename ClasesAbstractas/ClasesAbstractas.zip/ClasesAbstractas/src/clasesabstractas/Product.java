/*
 *  La clase Product es una clase abstracta que tiene un método abstracto llamado computeSalePrice() y un atributo privado double denominado regularPrice. Crear el constructor de la clase con parámetro que permita inicializar el estado del atributo, los métodos get y set de regularPrice, además del método abstracto computeSalePrice().
 */
package clasesabstractas;

/**
 *
 * @author Laura Camila Díaz, Daniel Alejandro Ayala, Alejandro Velandia
 */
public abstract class Product {
    private double regularPrice;
    
    public Product(double regularPrice){
        this.regularPrice = regularPrice;
    }
    
    public double getRegularPrice(){
        return regularPrice;
    }
    
    public void setRegularPrice(double regularPrice){
        this.regularPrice = regularPrice;
    }
    
    public abstract double computeSalePrice();
    
}
