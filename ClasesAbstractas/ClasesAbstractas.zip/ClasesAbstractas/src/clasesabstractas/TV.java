/*
 * La clase TV contiene un atributo int size, extiende la clase abstracta Electronics, elaborar el constructor de la clase con parámetros que permita inicializar el estado de los atributos (tener en cuenta de encadenar el constructor del padre con super()) y los métodos get y set de size. La clase debe implementar el método computeSalePrice() que debe retornar el 80% de regularPrice.
 */
package clasesabstractas;

/**
 *
 * @author Laura Camila Díaz, Daniel Alejandro Ayala, Alejandro Velandia
 */
public class TV extends Electronics {
    private int size;
    
    public TV(double regularPrice, String manufacturer, int size){
        super(regularPrice, manufacturer);
        this.size = size;
    }
    
    public int getSize(){
        return size;
    }
    
    public void setSize(int size){
        this.size = size;
    }
    
    @Override
    public double computeSalePrice(){
        return getRegularPrice() * 0.8;
    }

}
