/*
 * que herede de Product.  La clase Electronics es una clase abstracta porque no proporciona implementación del método abstracto computeSalePrice() y cree un atributo privado String denominado manufacturer. Crear el constructor de la clase con parámetros que permita inicializar el estado de los atributos (tener en cuenta de encadenar el constructor del padre con super()), los métodos get y set de manufacturer.
 */
package clasesabstractas;

/**
 *
 * @author Laura Camila Díaz, Daniel Alejandro Ayala, Alejandro Velandia
 */
public class Electronics extends Product {
    private String manufacturer;
    
    public Electronics(double regularPrice, String manufacturer){
        super(regularPrice);
        this.manufacturer = manufacturer;
    }
    
    public String getManufacturer(){
        return manufacturer;
    }
    
    public void setManufacturer(String manufacturer){
        this.manufacturer = manufacturer;
    }
    
    @Override
    public double computeSalePrice(){
        return 0;
    }

}
