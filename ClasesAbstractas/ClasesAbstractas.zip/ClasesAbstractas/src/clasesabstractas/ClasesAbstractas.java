/*En la clase principal (main) crear una estructura de datos tipo vector de Product y agregar diferentes objetos como TV, MP3 y Book, respectivamente; recorra la estructura de datos y totalice los valores de getRegularPrice (precio regular), del método abstracto computeSalePrice (precio de venta con descuento) y el total ahorrado, visualice los resultados por consola de cada aparato electrónico con su precio sin descuento, con descuento, valor ahorrado, y para todos los productos el total a pagar, el total ahorrado y el total sin descuento. */
package clasesabstractas;

/**
 *
 * @author Laura Camila Díaz, Daniel Alejandro Ayala, Alejandro Velandia
 */
public class ClasesAbstractas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Product[] products = new Product[3];
        products[0] = new TV(1000, "Sony", 30);
        products[1] = new MP3Player(200, "Apple", "iPod");
        products[2] = new Book(150, "Pearson", 2010);
        
        double totalRegularPrice = 0;
        double totalSalePrice = 0;
        
        for (Product product : products){
            System.out.println("..........................");
            System.out.println("");
            double regularPrice = product.getRegularPrice();
            double salePrice = product.computeSalePrice();
            
            System.out.println("Regular price = " + regularPrice);
            System.out.println("Sale price = " + salePrice);
            System.out.println("Discount = "+(regularPrice-salePrice));
            System.out.println("");
            
            totalRegularPrice += regularPrice;
            totalSalePrice += salePrice;
            
        }
        System.out.println("----------------------------------------------");
        System.out.println("totalRegularPrice = " + totalRegularPrice);
        System.out.println("totalSalePrice = " + totalSalePrice);
        System.out.println("Total discount = "+(totalRegularPrice-totalSalePrice));

    }
    
}
