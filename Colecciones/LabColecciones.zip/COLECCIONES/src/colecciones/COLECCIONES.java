
package colecciones;

/**
 *
 * @author Camila Diaz
 */
public class COLECCIONES {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		CuentaPalabras contador = new CuentaPalabras();
		contador.contarPalabras();
	}
	
}
