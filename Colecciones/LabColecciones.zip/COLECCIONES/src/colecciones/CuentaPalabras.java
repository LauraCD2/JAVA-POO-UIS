/*
 * implementación HashMap donde:
 * dada una cadena de caracteres cuente cuantas veces aparece cada palabra en la cadena.
•Utilizar el método split en String para separar las palabras
String st = «este es un texto ejemplo este ejemplo es para probar»
String[] palabras = st.split(" ");
Nota: Cuando se realiza una asociación se sobrescribe el valor anterior
 */
package colecciones;
import java.util.HashMap;

/**
 *
 * @author Camila Diaz
 */
public class CuentaPalabras {
        //metodo para contar las palabras
        public void contarPalabras(){
            //crear un string con el texto a analizar
            String st = "EsTe Es Un TeXtO eJeMpLo EsTe EjEmPlO eS pArA pRoBaR";
            //convertir el string en mayusculas para poder comparar las palabras y no tener problemas con las mayusculas y minusculas
            st = st.toUpperCase();
            //separar las palabras
            String[] palabras = st.split(" ");
            //crear un HashMap para almacenar las palabras y su cantidad de veces que aparecen en el texto
            HashMap<String, Integer> contador = new HashMap<String, Integer>();
            //recorrer el arreglo de palabras y contarlas con un for each y un if else para saber si la palabra ya esta en el HashMap o no y asi poder sumarle 1 a la cantidad de veces que aparece
            for (String palabra : palabras) {
                if (contador.containsKey(palabra)) {
                    contador.put(palabra, contador.get(palabra) + 1);
                } else {
                    contador.put(palabra, 1);
                }
            }
            //convertir el string al inicial para poder imprimirlo
            st = st.toLowerCase();
            //imprimir el HashMap con las palabras y su cantidad de veces que aparecen en el texto y el texto a analizar 
            System.out.println("CANTIDAD DE VECES QUE APARECE UNA PALABRA EN EL TEXTO ----> "+(char)34+" "+st+" "+(char)34+" <----"); 
            System.out.println("");
            System.out.println(contador);
        }
}


