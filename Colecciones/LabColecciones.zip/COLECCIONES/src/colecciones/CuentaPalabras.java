/*
 * implementación HashMap donde:
 * dada una cadena de caracteres cuente cuantas veces aparece cada palabra en la cadena.
•Utilizar el método split en String para separar las palabras
String st = «este es un texto ejemplo este ejemplo es para probar»
String[] palabras = st.split(" ");
Nota: Cuando se realiza una asociación se sobrescribe el valor anterior
 */
package colecciones;
import java.util.HashMap;

/**
 *
 * @author Camila Diaz
 */
public class CuentaPalabras {
        public void contarPalabras(){
            String st = "este es un texto ejemplo este ejemplo es para probar";
            String[] palabras = st.split(" ");
            HashMap<String, Integer> contador = new HashMap<String, Integer>();
            for (String palabra : palabras) {
                if (contador.containsKey(palabra)) {
                    contador.put(palabra, contador.get(palabra) + 1);
                } else {
                    contador.put(palabra, 1);
                }
            }
            System.out.println("CANTIDAD DE VECES QUE APARECE CADA PALABRA EN EL TEXTO ----> " +st+" <----");
            System.out.println("");
            System.out.println(contador);
        }
}


