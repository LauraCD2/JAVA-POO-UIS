/*
 * Interfaz tipo Map de la clase CuentaPalabras
 */
package colecciones;
import java.util.Map;

/**
 *
 * @author Camila Diaz
 */
public interface Interfaz {
    public Map<String, Integer> contarPalabras();
}
