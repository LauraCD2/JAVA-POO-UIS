/* implementación HashMap donde:
 * Solicite a un usuario una lista de palabras
 * Cuando el usuario ingrese la palabra "fin" no se solicitaran mas palabras
 * Calcule cuantas palabras tienen un número par de caracteres y cuantas un número impar de caracteres
 * Determine cual es la mas corta y cual la mas larga y eliminelas
 * Imprima la lista de palabras sin las palabras mas corta y mas larga
 * u
 */
package coleccionesgrupal;
import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author AYALA VELANDIA DIAZ
 */
public class Lista {
    private HashMap<String, Integer> listaPalabras = new HashMap<>();
    private String palabra;
    private int contadorPar = 0;
    private int contadorImpar = 0;
    private int contadorPalabras = 0;
    private String palabraMasLarga = "";
    private String palabraMasCorta = "";
    private int longitudPalabraMasLarga = 0;
    private int longitudPalabraMasCorta = 0;

    // constructor para inicializar la lista
    public void contarPalabras() {
        try (Scanner entrada = new Scanner(System.in)) {
            System.out.println("Ingrese una palabra: ");
            palabra = entrada.nextLine();
            // ciclo para ingresar palabras hasta que se ingrese la palabra "fin"
            while (!palabra.equals("fin")) {
                listaPalabras.put(palabra, palabra.length());
                if (palabra.length() % 2 == 0) {
                    contadorPar++;
                } else {
                    contadorImpar++;
                }
                if (contadorPalabras == 0) {
                    palabraMasLarga = palabra;
                    palabraMasCorta = palabra;
                    longitudPalabraMasLarga = palabra.length();
                    longitudPalabraMasCorta = palabra.length();
                } else {
                    if (palabra.length() > longitudPalabraMasLarga) {
                        palabraMasLarga = palabra;
                        longitudPalabraMasLarga = palabra.length();
                    }
                    if (palabra.length() < longitudPalabraMasCorta) {
                        palabraMasCorta = palabra;
                        longitudPalabraMasCorta = palabra.length();
                    }
                }
                contadorPalabras++;
                System.out.println("Ingrese una palabra: ");
                palabra = entrada.nextLine();
            }
        }
        // impresión de resultados
        System.out.println("La cantidad de palabras con un número par de caracteres es: " + contadorPar);
        System.out.println("La cantidad de palabras con un número impar de caracteres es: " + contadorImpar);
        System.out.println("La palabra mas larga es: " + palabraMasLarga);
        System.out.println("La palabra mas corta es: " + palabraMasCorta);
        // eliminación de palabras más larga y más corta
        listaPalabras.remove(palabraMasLarga);
        listaPalabras.remove(palabraMasCorta);
        System.out.println("La lista de palabras sin las palabras mas corta y mas larga es: " + listaPalabras);
        
    }
}
