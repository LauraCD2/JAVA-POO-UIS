/*
main 
 */
package coleccionesgrupal;

/**
 *
 * @author AYALA VELANDIA DIAZ
 */
public class ColeccionesGrupal {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		Lista contador = new Lista();
		contador.contarPalabras();
	}
	
}
