
package parcial.pkg1;

/**
 *
 * @author Cami
 */
public class Servicio {
    //Atributos
    private Muestra[] Simples;
    private Muestra[] Complejas;
    private int cantidadSimples;
    private int cantidadComplejas;
    private double promComplejas, promSimples, sumaComplejas = 0, sumaSimples = 0;

    // Getters ans setters

    public double getPromedioSimples() {return promSimples;}
    public double getPromedioComplejas() {return promComplejas;}
    public Muestra getMuestraSimple(int i) {return Simples[i];}
    public Muestra getMuestraCompleja(int i) {return Complejas[i];}
    public int getCantidadSimples() {return cantidadSimples;}
    public void setCantidadSimples(int cantidadSimples) {this.cantidadSimples = cantidadSimples;}
    public int getCantidadComplejas() {return cantidadComplejas;}
    public void setCantidadComplejas(int cantidadComplejas) {this.cantidadComplejas = cantidadComplejas;}

    // Constructor
    public Servicio() {
        Complejas = new Muestra[30];
        Simples = new Muestra[30];
        cantidadSimples = 0;
        cantidadComplejas = 0;
    }

    // Metodo agregar muestras
    public void agregarMuestra(Muestra m) {
        if (m.getProfundidad() <= 10) {
            m.setClasificacion("Simple");
            Simples[cantidadSimples] = m;
            cantidadSimples++;
        } else {
            m.setClasificacion("Compleja");
            Complejas[cantidadComplejas] = m;
            cantidadComplejas++;
        }
    }

    public void Promedios() {

        if (cantidadComplejas!=0) {
            for (int i = 0; i < cantidadComplejas; i++) {
                /*
                 * System.out.println("Muestra #" + i);
                 * System.out.println("Serial: " + muestrasComplejas[i].getSerial());
                 * System.out.println("Fecha:" + muestrasComplejas[i].getFecha());
                 * System.out.println("Profundidad:" + muestrasComplejas[i].getProfundidad());
                 * System.out.println("Clasificacion: " +
                 * muestrasComplejas[i].getClasificacion());
                 */
                sumaComplejas = sumaComplejas + Complejas[i].getProfundidad();
            }
            promComplejas = ((double) sumaComplejas / cantidadComplejas);

        }if(cantidadComplejas==0){promComplejas=0;}
        if (cantidadSimples != 0) {
            for (int i = 0; i < cantidadSimples; i++) {
                /*
                 * System.out.println("Muestra #" + i);
                 * System.out.println("Serial: " + muestrasSimples[i].getSerial());
                 * System.out.println("Fecha:" + muestrasSimples[i].getFecha());
                 * System.out.println("Profundidad:" + muestrasSimples[i].getProfundidad());
                 * System.out.println("Clasificacion: " +
                 * muestrasSimples[i].getClasificacion());
                 */
                sumaSimples = sumaSimples + Simples[i].getProfundidad();
            }
            promSimples = ((double) sumaSimples / cantidadSimples);
            
        }if(cantidadSimples==0){promSimples=0;}

}
}
