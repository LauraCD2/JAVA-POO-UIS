
package parcial.pkg1;

/**
 *
 * @author JUAN
 */
public class Laboratorio {
    // Atributos
    Servicio[] listadoServicios;
    int cantidad;

    // Constructor
    public Laboratorio() {

        listadoServicios = new Servicio[100];
        cantidad = 0;
    }

    // Metodo para agregar servicios
    public void AgregarServicioAlListado(Servicio servicio) {

        listadoServicios[cantidad] = servicio;
        cantidad++;

    }

    public void RegistrarMuestra(Muestra muestra, int numero) {

        listadoServicios[numero].agregarMuestra(muestra);

    }

    public void ImprimirInforme() {
        
int costoTotal;
for(int i=0;i<cantidad;i++){
costoTotal=(listadoServicios[i].getCantidadComplejas()*1000000)+(listadoServicios[i].getCantidadSimples()*400000);
    System.out.println("Servicio #"+i);
    System.out.println("Promedio simples con muestras simples "+listadoServicios[i].getCantidadSimples()+": "+listadoServicios[i].getPromedioSimples());
    System.out.println("Promedio simples con muestras complejas "+listadoServicios[i].getCantidadComplejas()+": "+listadoServicios[i].getPromedioComplejas());
System.out.println("Costo total: "+costoTotal);
}


    }}