/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package parcial.pkg1;
import java.util.Scanner;

/**
 *
 * @author JUAN
 */
public class LaMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // variables
        int opt;
        int optMuestra;
        Scanner in = new Scanner(System.in);
        Laboratorio l1 = new Laboratorio();
        Servicio s1 = new Servicio();

        // menu
        do {
            System.out.println("Creando servicio...");
            //Servicio s1 = new Servicio();
            System.out.println("Servicio creado.... ");
            do {
                //String serial, fecha;
                //int profundidad;

                System.out.println("...Ingrese la muestra del servicio...");

                System.out.println("Digite el serial");
                String serial = in.next();
                

                System.out.println("Digite la fecha");
                String fecha = in.next();

                System.out.println("Digite profundidad");
                int profundidad = in.nextInt();

                

                Muestra m1 = new Muestra(serial, profundidad, fecha);
                s1.agregarMuestra(m1);

                System.out.println("¿Desea agregar más muestras? | 1.Si | 2.No |");
                optMuestra = in.nextInt();
            } while (optMuestra != 2);

            l1.AgregarServicioAlListado(s1);
            System.out.println("¿Desea agregar más servicios? | 1.Si | 2.No |");

            opt = in.nextInt();
        } while (opt != 2);
        
        // mostrar}
        s1.Promedios();
        l1.ImprimirInforme();

        in.close();
    }
    
}
