/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial.pkg1;

/**
 *
 * @author JUAN
 */
public class Muestra {
    //Atributos
private String serial;
private int profundidad;
private String fecha;
private String clasificacion;

//Metodos Getters ans setters
public int getProfundidad(){return profundidad;}
public void setProfundidad(int profundidad){this.profundidad=profundidad;}
public String getSerial() {return serial;}
public void setSerial(String serial) {this.serial = serial;}
public String getFecha() {return fecha;}
public void setFecha(String fecha) {this.fecha = fecha;}
public String getClasificacion() {return clasificacion;}
public void setClasificacion(String clasificacion) {this.clasificacion = clasificacion;}

// Constructor
public Muestra( String se,int pr,String fe){
serial=se;
profundidad=pr;
fecha=fe;
clasificacion="Sin clasificar";
}
}
