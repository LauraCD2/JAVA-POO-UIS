/*
 * Implemente una aplicacion que permita registrar un determinado país
 * desde un cuadro de texto (JTextField) se almacene al dar click en el botón REGISTRAR e imprima en una lista (JList), 
 * Al presionar REGISTRAR se muestre dentro de una lista (JList).
 * Debajo un botón resumen que al dar click abra un cuadro de texto (JTextField) donde diga:
 * Total de paises registrados:
 * primer país registrado:
 * último país registrado:
 */
package guid2;
import javax.swing.*;

/**
 *
 * @author Camila Díaz 
 */
public class pais extends JFrame{
    private JLabel label1;
    private JTextField text1;
    private JButton boton1, boton2;
    private JList lista1;
    private String[] paises = new String[1000];
    private int contador = 0;
    
    public pais(){
        setLayout(null);
        label1 = new JLabel("Pais:");
        label1.setBounds(10, 10, 100, 30);
        add(label1);
        
        text1 = new JTextField();
        text1.setBounds(120, 10, 100, 30);
        add(text1);
        
        boton1 = new JButton("Registrar");
        boton1.setBounds(10, 50, 100, 30);
        add(boton1);
        //Almacenar el pais e imprimirlo en la lista
        boton1.addActionListener((e) -> {
            paises[contador] = text1.getText();
            contador++;
            text1.setText("");

            lista1 = new JList();
        lista1.setBounds(10, 90, 200, 200);
        add(lista1);
        lista1.setListData(paises);
        });
        
        boton2 = new JButton("Resumen");
        boton2.setBounds(120, 50, 100, 30);
        add(boton2);
        //Mostrar el resumen
        boton2.addActionListener((e) -> {
            String resumen = "Total de paises registrados: " + contador + " " +
                    "Primer pais registrado: " + paises[0] + " " +
                    "Ultimo pais registrado: " + paises[contador - 1];
            JOptionPane.showMessageDialog(null, resumen);
        });
    }
}