/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package guid2;
import javax.swing.*;

/**
 *
 * @author User
 */
public class GUID2 extends JFrame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        pais ventana = new pais();
        ventana.setVisible(true);
        ventana.setSize(245, 400);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }
    
}
