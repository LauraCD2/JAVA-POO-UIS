package Practica1011;

//import java.util.Scanner;

/**
 *
 * @author Camila Diaz 
 */
public class practica1011 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        trabajador e1 = new trabajador();
        /*Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese el nombre del trabajador");
            String nombre = teclado.nextLine();
            System.out.println("Ingrese las horas trabajadas");
            int horas = teclado.nextInt();
            System.out.println("Ingrese el sueldo por hora");
            double sueldo = teclado.nextDouble();
            e1.nombre=nombre;
            e1.horas=horas;
            e1.sueldo=sueldo;*/
            e1.mostrar();
            e1.calcular();
            //e1.();
        }
    }
    

