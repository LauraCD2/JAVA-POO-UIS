//permita establecer e imprimir el nombre del propietario y la superficie de la casa.

/**
 *
 * @author Estudiante
 */
public class app {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        casa casa1 = new casa();
        casa1.setPropietario("Juan");
        casa1.setSuperficie(100);
        casa1.visualizar();
        
    }
    }
    