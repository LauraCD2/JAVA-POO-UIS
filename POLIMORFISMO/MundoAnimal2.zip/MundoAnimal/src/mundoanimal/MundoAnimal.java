package mundoanimal;

/**
 *
 * @author Camila Díaz
 */
public class MundoAnimal {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		Animal[] animales = new Animal[4];
		
		animales[0] = new Perro();
		animales[1] = new Lobo();
		animales[2] = new Gato();
		animales[3] = new Leon();
		
		for (int i = 0; i < animales.length; i++) {
		animales[i].hacerRuido();
		}
		
		for (Animal animal : animales) {
		animal.hacerRuido();
		}

		Canino can1 = new Lobo();
		Lobo lobo1 = new Lobo();
		lobo1 = (Lobo) can1;
		lobo1.hacerRuido();
	}
}
