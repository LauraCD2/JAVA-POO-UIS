
package mundoanimal;

/**
 *
 * @author Camila Díaz
 */
public class Canino extends Animal {
	public void desplazarse () {
        System.out.println("Desplazamiento en manada");
    }
}
