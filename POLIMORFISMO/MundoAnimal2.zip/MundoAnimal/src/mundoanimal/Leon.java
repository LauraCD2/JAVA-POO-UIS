package mundoanimal;

/**
 *
 * @author Camila Díaz
 */
public class Leon extends Felino {

    public void hacerRuido() {
    System.out.println("Grrrrrrr");
    }
    
}