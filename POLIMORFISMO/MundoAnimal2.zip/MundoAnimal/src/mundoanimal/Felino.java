
package mundoanimal;

/**
 *
 * @author Camila Díaz
 */
public class Felino extends Animal{
	public void desplazarse () {
        System.out.println("Desplazamiento solitario");
    }
}
