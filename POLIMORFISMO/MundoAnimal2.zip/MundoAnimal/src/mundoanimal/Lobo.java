package mundoanimal;

/**
 *
 * @author Camila Díaz
 */
public class Lobo extends Canino {
    public void hacerRuido() {
    System.out.println("Aauuuuuuu");
    }
}
