package mundoanimal;

/**
 *
 * @author Camila Díaz
 */
public class Perro extends Canino {
    public void hacerRuido() {
    System.out.println("Guau Guau");
    }
}
