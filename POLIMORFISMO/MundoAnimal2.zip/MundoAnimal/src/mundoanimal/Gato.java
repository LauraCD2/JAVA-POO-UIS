package mundoanimal;

/**
 *
 * @author Camila Díaz
 */
public class Gato extends Felino {
    public void hacerRuido() {
    System.out.println("Miau Miau");
    }
    }
