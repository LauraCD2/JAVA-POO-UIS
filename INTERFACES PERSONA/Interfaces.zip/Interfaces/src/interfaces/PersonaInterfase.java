/*
 * interface Java que contendrá tres métodos double imcPersona(), String getNombre() y String getApellido().
 */
package interfaces;

/**
 *
 * @author User
 */
public interface PersonaInterfase {
    public double imcPersona();
    public String getNombre();
    public String getApellido();
}
