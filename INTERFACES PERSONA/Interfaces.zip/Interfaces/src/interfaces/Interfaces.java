/*
 * cree una estructura de datos que almacene objetos de tipo "Persona" e imprima el nombre, apellido e IMC en consola.
 */
package interfaces;

/**
 *
 * @author User
 */
public class Interfaces {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Persona persona1 = new Persona(49, 1.52, "Camila", "Díaz");
        Persona persona2 = new Persona(70, 1.80, "Juan", "Velandia");
        Persona persona3 = new Persona(80, 1.90, "Pedro", "González");

        //imprimir
        System.out.println("Nombre: " + persona1.getNombre()); 
        System.out.println( "Apellido: " + persona1.getApellido() ); 
        System.out.println( "IMC: " + persona1.imcPersona());
        
        System.out.println("..........................");
        System.out.println("");
        
        System.out.println("Nombre: " + persona2.getNombre()); 
        System.out.println( "Apellido: " + persona2.getApellido() ); 
        System.out.println( "IMC: " + persona2.imcPersona());
        
        System.out.println("..........................");
        System.out.println("");

        System.out.println("Nombre: " + persona3.getNombre());
        System.out.println( "Apellido: " + persona3.getApellido() );
        System.out.println( "IMC: " + persona3.imcPersona());

        
        
    }
    
}
