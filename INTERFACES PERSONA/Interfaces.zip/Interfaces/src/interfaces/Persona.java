/*
 * Implemente una clase denominado: Persona.java: La clase "Persona" contiene los atributos peso y estatura ambos privados y double, otros String nombre y apellido también privados, crear el constructor de la clase con todos los atributos de la clase; además, implementar los métodos de la interface PersonaInterface, el método getNombre y getApellido que devuelven respectivamente tanto el nombre como el apellido y el método imcPersona retorna el calculo del IMC (indice de masa corporal) IMC = (peso/(estatura*estatura)) .
 */
package interfaces;

/**
 *
 * @author Camila Díaz
 */
public class Persona {
    private double peso;
    private double estatura;
    private String nombre;
    private String apellido;
    
    public Persona(double peso, double estatura, String nombre, String apellido){
        this.peso = peso;
        this.estatura = estatura;
        this.nombre = nombre;
        this.apellido = apellido;
    }
    
    public double imcPersona(){
        return peso/(estatura*estatura);
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public String getApellido(){
        return apellido;
    }
}
